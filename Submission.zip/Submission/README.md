All you have to do to play the game is load up the file master.rkt and run it.

The game should be pretty self explanatory and prompt you to do the things 
you wouldn't necessarily think to do.

If you need help of course the (help) command should have all the user commands you need.
Also the walkthrough is there in the code if you really need to look at that.